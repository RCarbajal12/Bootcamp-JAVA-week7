package com.romina.empleadosygerentes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpleadosygerentesApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpleadosygerentesApplication.class, args);
	}

}
