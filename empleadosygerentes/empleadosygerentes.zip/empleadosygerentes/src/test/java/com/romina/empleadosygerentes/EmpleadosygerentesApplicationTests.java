package com.romina.empleadosygerentes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpleadosygerentesApplicationTests {

	@Test
	void contextLoads() {
	}

}
