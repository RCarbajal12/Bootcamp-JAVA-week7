package com.romina.eventos.models;

public class Provincias {
	
	public static final String[] provincias = {"CA","MX", "WA","TX", "NV", "UY-CA"};
	

}
